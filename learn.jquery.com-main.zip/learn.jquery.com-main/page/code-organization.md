<script>{
	"title": "Code Organization",
	"level": "intermediate",
	"customFields": [
		{
			"key": "icon",
			"value": "sitemap"
		}
	]
}</script>

Understanding the basic mechanics is one thing, but the essence of building applications is understanding how to organize code so that it is navigable and well-encapsulated instead of a whole slew of global functions.
