<script>{
	"title": "Performance",
	"level": "intermediate",
	"customFields": [
		{
			"key": "icon",
			"value": "dashboard"
		}
	]
}</script>
