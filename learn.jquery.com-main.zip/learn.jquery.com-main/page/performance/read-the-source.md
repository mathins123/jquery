<script>{
	"title": "Don't Treat jQuery as a Black Box",
	"level": "intermediate",
	"source": "http://jqfundamentals.com/legacy",
	"attribution": [ "jQuery Fundamentals" ]
}</script>

Use the source as your documentation. Bookmark [the source code](https://releases.jquery.com/jquery/) and refer to it often.
