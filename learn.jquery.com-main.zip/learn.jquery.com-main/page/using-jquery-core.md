<script>{
	"title": "Using jQuery Core",
	"level": "beginner",
	"customFields": [
		{
			"key": "icon",
			"value": "star-empty"
		}
	]
}</script>
