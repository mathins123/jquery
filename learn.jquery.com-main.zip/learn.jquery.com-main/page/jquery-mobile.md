<script>{
	"title": "jQuery Mobile",
	"customFields": [
		{
			"key": "icon",
			"value": "th-large"
		}
	]
}</script>

jQuery Mobile is the easiest way to build sites and apps that are accessible on all popular smartphone, tablet, and desktop devices. This framework provides a set of touch-friendly UI widgets and an AJAX-powered navigation system to support animated page transitions.
