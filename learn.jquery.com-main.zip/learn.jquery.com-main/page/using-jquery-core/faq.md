<script>{
	"title": "Frequently Asked Questions",
	"level": "beginner",
	"customFields": [
		{
			"key": "icon",
			"value": "question-sign"
		}
	]
}</script>
