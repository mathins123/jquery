<script>{
    "title": "Contributing",
    "customFields": [
        {
            "key": "is_chapter",
            "value": 0
        }
    ]
}</script>

@partial(CONTRIBUTING.md)
