<script>{
	"title": "Using jQuery UI",
	"level": "intermediate"
}</script>

In addition to being available on [CDN](https://releases.jquery.com/ui/)s and [Download Builder](http://jqueryui.com/download/), jQuery UI also integrates into a number of development environments.
